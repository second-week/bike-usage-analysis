
#Loading the tidyverse package

  library(tidyverse)

  #Importing the sampled datasets. Earlier, I'd taken random samples for each month
  #as I wanted to work with the datasets on google sheets

  january <- read.csv("jan_sample.csv")
  february <- read.csv("feb_sample.csv")
  march <- read.csv("march_sample.csv")
  april <- read.csv("april_sample.csv")
  
  
                    #Cleaning the data
  
    
    #Using complete.cases to remove rows with any missing values. 
    jan_clean <- january[complete.cases(january), ]

    feb_clean <- february[complete.cases(february), ]
    march_clean <- march[complete.cases(march), ]
    april_clean <- april[complete.cases(april), ]
    colSums(is.na(april))
    # it didn't work
  
    View(april_clean)
    
      #There are rows with missing start and end station values
#Filter out rows with missing station names using dplyr
      
    jan_clean <- january % % 
          filter(!is.na(start_station_name) | !is.na(end_station_name))
    #filter out rows where the start or end stations are NAs
    View(jan_clean)
    #didn't work
      
    #trying other approaches
    
    jan_clean <- january % %
          filter(!is.na(start_station_name)) % % #filter out missing start stations
          filter(!is.na(end_station_name)) #then missing end stations
      
    clean_jan <- january % % 
          filter(!is.na(start_station_id)) #filter out missing station ids
    #none of these work. there are still missing values
    
    clean_jan <- january % % 
          filter(is.na(start_station_id)) #filtering to see only rows with missing ids

#checking if a blank cell I saw registers as NA
        is.na(jan_clean[1,7])
  [1] FALSE #it doesn't register as NA. This might mean cells with empty values 
        #don't register as NAs. Maybe it's because of the setting when importing the
        #datasets.
    
        #trying other approaches for the different ways a cell can be empty
        clean_jan <- january % % 
          filter(start_station_id != "" | end_station_name != "")
        #whether the start station or the end station info is empty this way
    View(clean_jan) #doesn't work
    
    clean_jan <- january % % 
          filter(start_station_id < 1 | end_station_name < 1)
    #using the possibility that blank cells are classed as zero and so, less than one
    #it didn't work

      #another approach
   clean_jan <- january % % 
      filter(start_station_name != "" & 
             end_station_name != "" & 
             start_station_id != "" & 
             end_station_id != "")
  #this worked. so removing other attempts I tried from the environment
     rm(april_clean, jan_clean, feb_clean, march_clean)

     #Running the filter for the datasets of the other months
   clean_feb <- february % % 
      filter(start_station_name != "" & 
               end_station_name != "" & 
               start_station_id != "" & 
               end_station_id != "")
    
  clean_march <- march % % 
  filter(start_station_name != "" & 
           end_station_name != "" & 
           start_station_id != "" & 
           end_station_id != "")

  clean_april <- april % % 
  filter(start_station_name != "" & 
           end_station_name != "" & 
           start_station_id != "" & 
           end_station_id != "")
  
  

#COnverting the first letters of the values in the rideable_type and member_column to
#uppercase:


 substr(clean_jan$rideable_type, 1, 1) <- toupper(substr(clean_jan$rideable_type, 1, 1))
 View(clean_jan) #checking if it works. (rideable type column). 
 
 #it does, so doing this for the other months
 
 substr(clean_feb$rideable_type, 1, 1) <- toupper(substr(clean_feb$rideable_type, 1, 1))
 substr(clean_march$rideable_type, 1, 1) <- toupper(substr(clean_march$rideable_type, 1, 1))
 substr(clean_april$rideable_type, 1, 1) <- toupper(substr(clean_april$rideable_type, 1, 1))
 
 #doing the same for the member_casual column
 substr(clean_jan$member_casual, 1, 1) <- toupper(substr(clean_jan$member_casual, 1, 1))
 View(clean_jan) #checking

 #it works so doing it for the other datasets
 substr(clean_feb$member_casual, 1, 1) <- toupper(substr(clean_feb$member_casual, 1, 1))
 View(clean_feb)
 substr(clean_march$member_casual, 1, 1) <- toupper(substr(clean_march$member_casual, 1, 1))
 substr(clean_april$member_casual, 1, 1) <- toupper(substr(clean_april$member_casual, 1, 1))
 View(clean_april)

#using regex to remove the underscore in the values of the rideable_type column 

 clean_jan$rideable_type <- gsub("_", " ", clean_jan$rideable_type)
 clean_feb$rideable_type <- gsub("_", " ", clean_feb$rideable_type)
 clean_march$rideable_type <- gsub("_", " ", clean_march$rideable_type)
 clean_april$rideable_type <- gsub("_", " ", clean_april$rideable_type)

 
#Converting rideable_type and member_casual variables to factors
  #first checking the unique values
 unique(clean_jan$rideable_type)
 unique(clean_jan$member_casual)

#Converting to factor
  clean_jan$rideable_type <- factor(clean_jan$rideable_type)
  clean_jan$member_casual <- factor(clean_jan$member_casual)
  
  #feb
  clean_feb$rideable_type <- factor(clean_feb$rideable_type)
  clean_feb$member_casual <- factor(clean_feb$member_casual)
  
  #march
  clean_march$rideable_type <- factor(clean_march$rideable_type)
  clean_march$member_casual <- factor(clean_march$member_casual)
  
  #april
  clean_april$rideable_type <- factor(clean_april$rideable_type)
  clean_april$member_casual <- factor(clean_april$member_casual)
 


#Calculating ride durations
  clean_jan$ride_duration <- as.numeric(
    difftime(clean_jan$ended_at, clean_jan$started_at, units = "secs"))
  
  
#The duration isn't displayed in the hour:minutes:seconds format. So to fix this, we
#have to format the durations, and to do so, we need to create a custom formula:
#Asked chatgpt to help me do this

  # Function to format seconds to 'hours:minutes:seconds'
  format_duration <- function(seconds) {
    hours <- seconds %/% 3600
    minutes <- (seconds %% 3600) %/% 60
    seconds <- seconds %% 60
    sprintf("%02d:%02d:%02d", hours, minutes, seconds)
  }
  
 #Applying function to trip_duration
 
   clean_jan$ride_duration <-  sapply(clean_jan$ride_duration, format_duration) 
   
  #calculating trip durations for the other months
  clean_feb$ride_duration <- as.numeric(
      difftime(clean_feb$ended_at, clean_feb$started_at, units = "secs"))
  clean_march$ride_duration <- as.numeric(
    difftime(clean_march$ended_at, clean_march$started_at, units = "secs"))
  clean_april$ride_duration <- as.numeric(
    difftime(clean_april$ended_at, clean_april$started_at, units = "secs"))
  
 #Applying the custom function to the remaining months
 clean_feb$ride_duration <- sapply(clean_feb$ride_duration, format_duration)
 clean_march$ride_duration <- sapply(clean_march$ride_duration, format_duration)
 clean_april$ride_duration <- sapply(clean_april$ride_duration, format_duration)
  
 #Observing the changes
  View(clean_jan)
  View(clean_feb)
  View(clean_march)
  View(clean_april)
  
  #Selecting only the columns that are necessary for analysis

  clean_jan <- clean_jan %>%
    select(ride_id, rideable_type, started_at, ended_at, start_station_name, 
           start_station_id, end_station_name, end_station_id, member_casual, 
           ride_duration)
  
  View(clean_jan) #checking
  
  #Other months
  
  clean_feb <- clean_feb %>%
    select(ride_id, rideable_type, started_at, ended_at, start_station_name, 
           start_station_id, end_station_name, end_station_id, member_casual, 
           ride_duration)
  clean_march <- clean_march %>%
    select(ride_id, rideable_type, started_at, ended_at, start_station_name, 
           start_station_id, end_station_name, end_station_id, member_casual, 
           ride_duration)
  clean_april <- clean_april %>%
    select(ride_id, rideable_type, started_at, ended_at, start_station_name, 
           start_station_id, end_station_name, end_station_id, member_casual, 
           ride_duration)
  
#Converting the started_at and ended_at columns to date_time format
  clean_jan$started_at <- ymd_hms(clean_jan$started_at)
  clean_jan$ended_at <- ymd_hms(clean_jan$ended_at)
  
  #Repeating for other months
  clean_feb$started_at <- ymd_hms(clean_feb$started_at)
  clean_feb$ended_at <- ymd_hms(clean_feb$ended_at)
  
  #March
  clean_march$started_at <- ymd_hms(clean_march$started_at)
  clean_march$ended_at <- ymd_hms(clean_march$ended_at)
  
  #April
  clean_april$started_at <- ymd_hms(clean_april$started_at)
  clean_april$ended_at <- ymd_hms(clean_april$ended_at)
  
  
#Extract day of the week and hour of the day

    clean_jan <- clean_jan %>%
      mutate(
        start_day_of_week = wday(started_at, label = TRUE),
        end_day_of_week = wday(ended_at, label = TRUE),
        start_hour = hour(started_at)
      )
  
  #Other months
  
    clean_feb <- clean_feb %>% 
      mutate(
        start_day_of_week = wday(started_at, label = TRUE),
        end_day_of_week = wday(ended_at, label = TRUE),
        start_hour = hour(started_at)
      )
  #March
    clean_march <- clean_march %>% 
      mutate(
        start_day_of_week = wday(started_at, label = TRUE),
        end_day_of_week = wday(ended_at, label = TRUE),
        start_hour = hour(started_at)
      )
  #April
    clean_april <- clean_april %>% 
      mutate(
        start_day_of_week = wday(started_at, label = TRUE),
        end_day_of_week = wday(ended_at, label = TRUE),
        start_hour = hour(started_at)
      )
  
  
  #Calculating the ride duration in seconds so it can  be used for analysis
  
    clean_jan <- clean_jan %>%
      mutate(
        ride_duration = as.numeric(
          difftime(ended_at, started_at, units = "secs"))
      )

    clean_feb <- clean_feb %>%
      mutate(
        ride_duration = as.numeric(
          difftime(ended_at, started_at, units = "secs"))
      )
  
  
    clean_march <- clean_march %>%
      mutate(
        ride_duration = as.numeric(
          difftime(ended_at, started_at, units = "secs"))
      )
  
    clean_april <- clean_april %>%
      mutate(
        ride_duration = as.numeric(
          difftime(ended_at, started_at, units = "secs"))
      )
    
    #Then deleting the ride_duration_in_secs column that's in the january dataset
    
    clean_jan <- clean_jan %>% 
       select(ride_id, rideable_type, started_at, ended_at, start_station_name, 
               start_station_id, end_station_name, end_station_id, member_casual, 
              ride_duration, start_day_of_week, end_day_of_week, start_hour)
  


        
# Checking for outliers    
#Visualizing the distribution of the January data using a boxplot

      ggplot(clean_jan, aes(member_casual, ride_duration/60)) + 
        geom_boxplot() +
        labs(title = "Ride Duration Distribution by Membership Type",
             x = "Membership Type",
             y = "Ride Duration (Minutes)")
        
 #Creating function to remove outliers.
 #This function works by filtering out values that are 1.5 times the width of the
 #interquartile range from the lower bound and upper bound
 
      
      remove_outliers <- function(df, column) {
        Q1 <- quantile(df[[column]], 0.25)
        Q3 <- quantile(df[[column]], 0.75)
        IQR <- Q3 - Q1
        
        lower_bound <- Q1 - 1.5 * IQR
        upper_bound <- Q3 + 1.5 * IQR
        
        df <- df %>%
          filter(df[[column]] >= lower_bound & df[[column]] <= upper_bound)
        
        return(df)
      }
      
  
    #Creating forked datasets to remove the outliers
    
    none_jan <- remove_outliers(clean_jan, "ride_duration")
    none_feb <- remove_outliers(clean_feb, "ride_duration")
    none_march <- remove_outliers(clean_march, "ride_duration")
    none_april <- remove_outliers(clean_april, "ride_duration")
    
    


     
    
#                          ANALYSIS PHASE                                   

    
    
    
#Calculating summary statistics for each customer type in January

    jan_summary_stats <- none_jan %>% 
      group_by(member_casual) %>% 
      summarise(
        num_of_rides = n(),
        average_duration = round(mean(ride_duration / 60), 2),
        median_duration = round(median(ride_duration / 60), 2),
        st_dev = round(sd(ride_duration / 60), 2)
      )
    
    #Other months
    
    feb_summary_stats <- none_feb %>% 
      group_by(member_casual) %>% 
      summarise(
        num_of_rides = n(),
        average_duration = round(mean(ride_duration / 60), 2),
        median_duration = round(median(ride_duration / 60), 2),
        st_dev = round(sd(ride_duration / 60), 2)
      )
    
    #March
    
    march_summary_stats <- none_march %>% 
      group_by(member_casual) %>% 
      summarise(
        num_of_rides = n(),
        average_duration = round(mean(ride_duration / 60), 2),
        median_duration = round(median(ride_duration/ 60), 2),
        st_dev = round(sd(ride_duration / 60), 2)
      )
    
    #April 
    
    april_summary_stats <- none_april %>% 
      group_by(member_casual) %>% 
      summarise(
        num_of_rides = n(),
        average_duration = round(mean(ride_duration / 60), 2),
        median_duration = round(median(ride_duration / 60), 2),
        st_dev = round(sd(ride_duration / 60), 2)
      )
    
    
    
    #      #Visualizing the distribution of ride duration by customer type for 
    #      January data (without any outliers) using a boxplot
    
    ggplot(none_jan, aes(member_casual, ride_duration/60, fill = member_casual)) + 
      geom_boxplot() +
      labs(title = "Ride Duration Distribution by Customer Type (January)",
           x = "Membership Type",
           y = "Ride Duration (Minutes)")
    
    
    
    #Time based analysis
    

    # Plotting the distribution of rides by hour of the day
    
      ggplot(none_jan, aes(start_hour, fill = member_casual)) + 
        geom_histogram(binwidth = 1, position = "dodge") +
        labs(title = "Distribution of Trips by Hour of the Day (January)",
             x = "Hour of the Day",
             y = "Number of Trips")
      
    #Plotting the distribution of rides by day of the week
    
      ggplot(none_jan, aes(start_day_of_week, fill = member_casual)) +
        geom_bar(position = 'dodge') +
        labs(title = "Distribution of Trips by Day of the Week (January)",
             x = "Day of the Week",
             y = "Number of Trips")
      
      #Station usage
      
      #Start stations
      jan_start_station_popularity <- none_jan %>% 
        group_by(start_station_name, member_casual) %>% 
        summarise(num_of_rides = n()) %>% 
        arrange(desc(num_of_rides))
      
      #End stations
      jan_end_station_popularity <- none_jan %>% 
        group_by(end_station_name, member_casual) %>% 
        summarise(num_of_rides = n()) %>% 
        arrange(desc(num_of_rides))
      
    
  
      
  "
Will be taking a different approach now. This time, I'll combine the datasets
and analyse it on a macro level.
      
      Steps to take
      
   Analyze Combined Data First, Then Drill Down
      
   1.   Combine the Cleaned Datasets:
        After cleaning each dataset, combine them into a single dataset. 
        This allows me to perform an overall analysis first.

   2.   Perform Aggregate Analysis:
      Conduct the analysis on the combined dataset to identify broad trends
      and patterns. This helps to get a macro view of the data before drilling down.
      
      "
  
  #Having cleaned the dataset, the next step is to combine them:
    combined_data <- bind_rows(none_jan, none_feb, none_march, none_april)

  #Step 2: Performing analysis on combined data
  

  #2a.
  #Doing some descriptive statistics
  
 
  #Visualizing the distribution of ride duration for member and casual customers in seconds
  
  ggplot(combined_data, aes(ride_duration, fill = member_casual)) +
    geom_histogram(binwidth = 60, position = "dodge") +
    labs(title = "Distribution of Ride Durations by Customer Type (Jan to April)",
         x = "Ride Duration (seconds)", y = "Count")
  
  #This was in seconds and so not easily understandable. So I did another plot this
  #time in minutes, dividing the seconds using the integer division operator. (%/%)
  
  
  ggplot(combined_data, aes(ride_duration %/% 60, fill = member_casual)) +
    geom_histogram(binwidth = 5, position = "dodge") + theme_minimal() +
    labs(title = "Distribution of Trip Duration by Customer Type (Jan to April)",
         x = "Trip Duration", y = "Number Of Trips") +
    theme(
      legend.position = c(0.9, 0.9),
      legend.title = element_blank(),
      legend.background = element_blank(),
      legend.key = element_blank(),
      plot.margin = unit(c(2, 2, 2, 2), "mm")
    )
  
 
      
    #Adding a month variable to the combined dataset
    combined_data <- combined_data %>%
      mutate(month = format(started_at, "%b"))
    
    #Analysizing the ride trends of customer type by month
    
    month_comparison <- combined_data %>% 
      group_by(month, member_casual) %>% 
      summarise(num_of_rides = n(),
                average_duration = mean(ride_duration),
                median_duration = median(ride_duration),
                st_dev = sd(ride_duration)
                )
#The month in this result is ordered alphabetically with april coming first.
#To fix this I'll convert the month column to a factor and then order it.

    combined_data$month <- factor(combined_data$month, 
                                  levels = unique(format(sort(
                                    unique(combined_data$started_at)), "%b")),
                                  ordered = TRUE)
    
#Redoing the month comparison aggregation

    month_comparison <- combined_data %>% 
      group_by(month, member_casual) %>% 
      summarise(num_of_rides = n(),
                average_duration = mean(ride_duration),
                median_duration = median(ride_duration),
                st_dev = sd(ride_duration) 
      )
    
 #Plotting the average ride duration of the different customer groups over time
 
    ggplot(month_comparison, aes(month, average_duration %/% 60, 
                                 colour = member_casual, group = member_casual)) +
                              geom_line() + ylim(6, 13) +
      labs(title = 'Average trips durations are trending up',
            subtitle = "Average trip duration by month and user type (Jan to April)",
                      x = NULL,
                      y = "Average duration") + 
      theme_minimal() +
      theme(
        legend.position = c(0.9, 0.9),
        legend.title = element_blank(),
        legend.background = element_blank(),
        legend.key = element_blank(),
        plot.margin = unit(c(6, 4, 6, 4), "mm")
      )
                 
    
    #Plotting the median ride duration
    
    ggplot(month_comparison, aes(month, median_duration %/% 60, 
                                 colour = member_casual, group = member_casual)) +
      geom_line() + 
      labs(title = "Median Trip Duration by Month and Customer Type (Jan to April)",
           x = "Month",
           y = "Median Trip Duration") +
      theme_minimal() +
      theme(
        legend.position = c(0.9, 0.85),
        legend.title = element_blank(),
        legend.background = element_blank(),
        legend.key = element_blank(),
        plot.margin = unit(c(2, 2, 2, 2), "mm")
      )
      
      #A boxplot to display interquartile ranges.
      
    ggplot(combined_data, aes(member_casual, ride_duration/60, 
                                 fill = member_casual)) +
      geom_boxplot() + 
      labs(title = 'Trips by casual riders are often longer',
        subtitle = "Trip durations range by user type (Jan to April)",
           x = NULL,
           y = "Trip duration (minutes)") +
      theme_minimal() +
      theme(
        legend.position = c(0.9, 0.95),
        legend.title = element_blank(),
        legend.background = element_blank(),
        legend.key = element_blank(),
        plot.margin = unit(c(4, 4, 4, 4), "mm")
      )
    
    #A geom_density version
    
    ggplot(combined_data, aes(ride_duration/60, colour = member_casual)) +
      geom_density() +
      theme_minimal() +
      theme(
        legend.position = c(0.9, 0.95),
        legend.title = element_blank(),
        legend.background = element_blank(),
        legend.key = element_blank(),
        plot.margin = unit(c(4, 4, 4, 4), "mm")
      )
    
 
    
    
    #2b.
    # Usage patterns by time
    
    #First let's find out the usage patterns by time of day
    
    hourly_stats <- combined_data %>% 
      group_by(start_hour, member_casual) %>% 
      summarise(num_of_rides = n(),
        average_duration = mean(ride_duration),
                median_duration = median(ride_duration)
                )
    
 #And then by day of week
 
      weekly_rides <- combined_data %>% 
        group_by(start_day_of_week, member_casual) %>% 
        summarise(
          num_of_rides = n(),
          average_duration = mean(ride_duration),
          median_duration = median(ride_duration)
        )
    
    
    #Plotting the results
    
      #Plotting the distribution of rides by day of the week
      
      ggplot(weekly_rides, aes(start_day_of_week, num_of_rides, fill = member_casual)) +
        geom_bar(stat = 'identity', position = 'dodge') + theme_minimal() +
        
        geom_text(aes(label = num_of_rides), 
                  position = position_dodge(width = 0.9), 
                  vjust = 1.5, 
                  color = "black", 
                  size = 3)  +
        
        ylim(0, 7000) +
        labs(title = "Distribution of Trips by Day of the Week (Jan to April)",
             x = "Day of the Week",
             y = "Number of Trips") +
        theme(
          legend.position = c(0.9, 0.9),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank(), 
          legend.text = element_text(size = 8.65),
          plot.margin = unit(c(2, 2, 2, 2), "mm")
        )
      
      #Plotting the average trip duration by day of the week
      
      ggplot(weekly_rides, aes(start_day_of_week, average_duration %/% 60, 
                               colour = member_casual, group = member_casual)) +
        geom_line() + ylim(6, 14) +
        labs(title = 'Casual riders take shorter rides on weekdays',
            subtitle = "Average trip duration by day of the week (Jan to April)",
             x = "Day of the week",
             y = "Average duration (in minutes)") +
        theme_minimal() +
        theme(
          legend.position = c(0.5, 0.93),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank(),
          plot.margin = unit(c(2, 2, 2, 2), "mm")
        )
      
      
      #Plotting the median to help check outliers skewing the averages
      
      ggplot(weekly_rides, aes(start_day_of_week, median_duration %/% 60, 
                               colour = member_casual, group = member_casual)) +
        geom_line() + ylim(6, 11) +
        labs(title = 'Casual riders take shorter rides on weekdays',
            subtitle = "Median Trip Duration by Day of the Week (Jan to April)",
             x = "Day of the Week",
             y = "Median Duration") +
        theme_minimal() +
        theme(
          legend.position = c(0.5, 0.93),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank(),
          plot.margin = unit(c(2, 2, 2, 2), "mm")
        )
      
      
      
      
      
      # Plotting the number of rides by hour of the day
      
      ggplot(combined_data, aes(start_hour, fill = member_casual)) + 
        geom_histogram(binwidth = 1, position = "dodge") +
        labs(title = "Distribution of Trips by Hour of the Day (Jan to April)",
             x = "Hour of the Day",
             y = "Number of Trips")  +
        theme_minimal() +
        theme(
          legend.position = c(0.9, 0.9),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank(),
          plot.margin = unit(c(2, 2, 2, 2), "mm")
        )
      
    

      
      #Average duration by hour of the day
      
      ggplot(hourly_stats, aes(x = start_hour, y = average_duration %/% 60, 
                               color = member_casual, group = member_casual)) +
        geom_line() + ylim(5, 14) + 
        xlim(5, 23) + #limits the plot to only data starting from 5am to 11pm
        labs(title = 'Trip duration for casual riders varies during the day',
            subtitle = "Average trip duration by hour of the day (Jan to April)",
             x = "Hour of the day",
             y = "Average trip duration (minutes)") +
        theme_minimal() +
        theme(
              legend.position = c(0.9, 0.9),
              legend.title = element_blank(),
              legend.background = element_blank(),
              legend.key = element_blank(),
          plot.margin = unit(c(2, 2, 2, 2), "mm")
              )
      
      
      
      #Median trip duration by hour of the day
      
      ggplot(hourly_stats, aes(x = start_hour, y = median_duration %/% 60, 
                               color = member_casual, group = member_casual)) +
        geom_line() + ylim(5, 12) +
        xlim(5, 23) + #limits the plot to only data starting from 5am to 11pm
        labs(title = "Median Trip Duration by Hour of the Day (Jan to April)",
             x = "hour of the day",
             y = "median duration") +
        theme_minimal() +
        theme(
          legend.position = c(0.9, 0.9),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank()
        )
      
      
      


                  #Analysing station usage

      #First, finding out the most popular start stations
      
      popular_stations <- combined_data %>% 
        group_by(start_station_name, member_casual) %>% 
        summarise(num_of_rides = n()) %>% 
        arrange(desc(num_of_rides))

 "
 When I ran this code, I observed that the station with most rides were the ones
 with annual members. While this could help me understand the station usage of annual
 members, I would have little information on the station usage of casual riders.
 To fix this, I wanted to create a plot and then use the facet_wrap function to 
 divide the plot into members and casual riders. But I think it's better to create
 separate aggregations for each customer type. So I'll use the filter function
 instead.
 "
  #Top 10 most used stations for members
 members_pop_stations <- combined_data %>% 
   filter(member_casual == 'Member') %>% 
   group_by(start_station_name) %>% 
   summarise(num_of_rides = n()) %>% 
   arrange(desc(num_of_rides)) %>% 
   head(10)
      
  #for casual
  casual_pop_stations <- combined_data %>% 
    filter(member_casual == 'Casual') %>% 
    group_by(start_station_name) %>% 
    summarise(num_of_rides = n()) %>% 
    arrange(desc(num_of_rides)) %>% 
    head(10)
    
      
  #Plotting the results
  
  ggplot(members_pop_stations, aes(reorder(start_station_name, num_of_rides), 
                                   num_of_rides)) +
    geom_bar(stat = 'identity', fill = '#00bfc4', width = 0.8) +
    coord_flip() +
    theme_minimal() +
    labs(title = "Top 10 Most Popular Start Stations For Annual Members 
         (Jan to April)",
         x = "Start Station",
         y = "Number of Trips") +
    theme(plot.title.position = "plot",
          plot.margin = unit(c(5, 5, 5, 5), "mm"))
      
      
   #For casual riders
   
  ggplot(casual_pop_stations, aes(reorder(start_station_name, num_of_rides), 
                                  num_of_rides)) +
    geom_bar(stat = 'identity', fill = '#f8766d', width = 0.8) +
    coord_flip() +
    theme_minimal() +
    labs(title = "Top 10 Most Popular Start Stations for Casual Riders 
         (Jan to April)",
         x = "Start Station",
         y = "Number of Trips") +
    theme(plot.title.position = 'plot',
          plot.margin = unit(c(5, 5, 5, 5), 'mm')) 
      
      
      
      #Top 2 most used stations by day of week
      
      #for members
      
      members_weekday_stations <- combined_data %>%
        filter(member_casual == 'Member') %>% #filtering for only members
        group_by(start_day_of_week, start_station_name) %>% 
        #grouping the data. the order in which the grouping is done matters
        summarise(num_of_rides = n()) %>% #counting rides for the groups
        arrange(start_day_of_week, desc(num_of_rides)) %>% #sorting the results
        group_by(start_day_of_week) %>% 
        #grouping by day this time to cancel out the first grouping and making a new one
        slice_head(n = 2) #taking the top 2 for each day
      
      #for casual riders
      casual_weekday_stations <- combined_data %>% 
        filter(member_casual == 'Casual') %>% 
        group_by(start_day_of_week, start_station_name) %>% 
        summarise(num_of_rides = n()) %>% 
        arrange(start_day_of_week, desc(num_of_rides)) %>% 
        group_by(start_day_of_week) %>% 
        slice_head(n = 2)
      
      
      
      #Plotting the results
      
      ggplot(members_weekday_stations, aes(fct_rev(start_day_of_week), num_of_rides, 
                                           fill = start_station_name)) +
        geom_bar(stat = 'identity', position = 'dodge') +
        
        geom_text(aes(label = start_station_name), 
                  position = position_dodge(width = 0.9), 
                  vjust = 0.3, 
                  hjust = 1.2, 
                  size = 3.1)  + 
        theme_minimal() +
        labs(title = "Top 2 Popular Start Stations by Weekday (Members)",
             x = "Day of Week",
             y = "Number of Trips",
             fill = 'Station Name') +
        theme(legend.position = 'none') +
        coord_flip()
        
      
      #Casual riders
      
      ggplot(casual_weekday_stations, aes(fct_rev(start_day_of_week), num_of_rides, 
                                          fill = start_station_name)) +
        geom_bar(stat = 'identity', position = 'dodge') +
        ylim(0, 55) +
        geom_text(aes(label = start_station_name), 
                  position = position_dodge(width = 0.9), 
                  vjust = 0.3, 
                  hjust = 0.6, 
                  size = 3.1)  + 
        theme_minimal() +
        labs(title = "Top 2 Popular Start Stations by Weekday (Casual)",
             x = "Day of Week",
             y = "Number of Trips",
             fill = 'Station Name') +
        theme(legend.position = 'none') +
        coord_flip()
    
      
      #And now for end stations
      
      members_pop_end_stations <- combined_data %>% 
        filter(member_casual == 'Member') %>% 
        group_by(end_station_name) %>% 
        summarise(num_of_rides = n()) %>% 
        arrange(desc(num_of_rides)) %>% 
        head(10)
     
      #Casual
      casual_pop_end_stations <- combined_data %>% 
        filter(member_casual == 'Casual') %>% 
        group_by(end_station_name) %>% 
        summarise(num_of_rides = n()) %>% 
        arrange(desc(num_of_rides)) %>% 
        head(10)
       
      #Top 2 most used stations by day of week
      
      #Member
      
      member_weekday_end_stations <- combined_data %>% 
        filter(member_casual == 'Member') %>% 
        group_by(start_day_of_week, end_station_name) %>% 
        summarise(num_of_rides = n()) %>% 
        arrange(start_day_of_week, desc(num_of_rides)) %>% 
        group_by(start_day_of_week) %>% 
        slice_head(n = 2)
      
      #casual
      
      casual_weekday_end_stations <- combined_data %>% 
        filter(member_casual == 'Casual') %>% 
        group_by(start_day_of_week, end_station_name) %>% 
        summarise(num_of_rides = n()) %>% 
        arrange(start_day_of_week, desc(num_of_rides)) %>% 
        group_by(start_day_of_week) %>% 
        slice_head(n = 2)
        
      
      # Plotting the results

      
      #Most used stations
      
      #Members
      
      ggplot(members_pop_end_stations, aes(reorder(end_station_name, num_of_rides), 
                                           num_of_rides)) +
        geom_bar(stat = 'identity', fill = '#00bfc4', width = 0.8) +
        coord_flip() +
        theme_minimal() +
        labs(title = "Top 10 Most Popular End Stations For Annual Members 
         (Jan to April)",
             x = "End Station",
             y = "Number of Trips") +
        theme(plot.title.position = "plot",
              plot.margin = unit(c(5, 5, 5, 5), "mm"))
      
      
      #Casual riders
      
      ggplot(casual_pop_end_stations, aes(reorder(end_station_name, num_of_rides), 
                                          num_of_rides)) +
        geom_bar(stat = 'identity', fill = '#f8766d', width = 0.8) + 
        coord_flip() +
        theme_minimal() +
        labs(title = "Top 10 Most Popular End Stations For Casual Riders 
         (Jan to April)",
                  x = "End Station",
                  y = "Number of Trips") +
        theme(plot.title.position = "plot",
              plot.margin = unit(c(5, 5, 5, 5), "mm"))
        
      
      #Most used end stations by weekday
      
      #Members
      
      ggplot(member_weekday_end_stations, aes(fct_rev(start_day_of_week), num_of_rides, 
                                              fill = end_station_name)) +
        geom_bar(stat = 'identity', position = 'dodge',width = 0.85) +
        geom_text(aes(label = end_station_name), 
                  position = position_dodge(width = 0.85), 
                  vjust = 0.3, 
                  hjust = 1.2, 
                  size = 3.1)  + 
        theme_minimal() +
        labs(title = "Top 2 Popular End Stations by Weekday (Members)",
             x = "Day of Week",
             y = "Number of Trips",
             fill = 'Station Name') +
        theme(legend.position = 'none') +
        coord_flip() 
      
      #Casual 
      
      ggplot(casual_weekday_end_stations, aes(fct_rev(start_day_of_week), num_of_rides, 
                                          fill = end_station_name)) +
        geom_bar(stat = 'identity', position = 'dodge', width = 0.85) +
        ylim(0, 60) +
        geom_text(aes(label = end_station_name), 
                  position = position_dodge(width = 0.85), 
                  vjust = 0.3, 
                  hjust = 0.7, 
                  size = 3.1)  +  
        theme_minimal() +
        labs(title = "Top 2 Popular End Stations by Weekday (Casual)",
             x = "Day of Week",
             y = "Number of Trips",
             fill = 'Station Name') +
        theme(legend.position = 'none') +
        coord_flip() 
      
  
#In each of the bar plots for the weekday analysis, the days are arranged starting
#from saturday. It would be better if they were aranged starting from Sunday. 
#To fix this we would figured out that as the week days column were already factors,
#this meant that something in the code was flipping the order of the days. 
#It seemed to be the coord_flip function so we ran a copy of the copy without the 
#coord_flip part. The result had the order as we wanted. 
#Knowing now that coord_flip flips the order, we decided to reorder the factors
#this time in descending order with Saturday coming first so that when we plot the
#data, the coord_flip function would flip the order back to how we want.
  
  #Reordering the factors for the top 2 weekday stations tables.   
    #We would do this using the factor reverse function in the forcats package
    
      members_weekday_stations$start_day_of_week <- 
        fct_rev(members_weekday_stations$start_day_of_week)
   
      casual_weekday_stations$start_day_of_week <-
        fct_rev(casual_weekday_stations$start_day_of_week)
      
      member_weekday_end_stations$start_day_of_week <- 
        fct_rev(member_weekday_end_stations$start_day_of_week)
      
      casual_weekday_end_stations$start_day_of_week <- 
        fct_rev(casual_weekday_end_stations$start_day_of_week)
      
    #Then redid the plots without changing anything.
    #It worked.

    #But a better way of doing this would've been to wrap the start_day_of_the_week
    #with the factor reverse function when specifying ggplot aesthetics.
    #This brings more flexibility as the aggregated tables could be used later on.
    #So for good practice, I'll reverse the factors back to their original format and then wrap the
    #column with the factor reverse function.
      
      
   
      
      
    #Additional analysis to answer other questions 
    
      #Analysing the frequency of bike trips for the user segments
      
      #Plotting the frequency of rides by customer group
      
      
      #Histogram
      ggplot(month_comparison, aes(month, num_of_rides, fill = member_casual)) +
        geom_histogram(stat = 'identity', position = 'dodge')+
        labs(title = "Trips Per Month By Customer Group (Jan to April)",
             x = "Month",
             y = "Number of Trips") +
        theme_minimal() +
        theme(
          legend.position = c(0.9, 0.9),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank()
        )
      
      #Adding a percentage of month's rides column to the source aggregation so we 
      #can show percentages.
      
      month_comparison <- month_comparison %>% 
        group_by(month) %>% 
        mutate(monthly_percentage = round(num_of_rides/sum(num_of_rides) * 100, 1))
      
      #Adding percentages to plot:
      
      ggplot(month_comparison, aes(month, monthly_percentage, 
                                   fill = member_casual)) +
        geom_bar(stat = 'identity', position = 'dodge')+
        labs(title = 'Annual members take more trips by a far distance',
            subtitle = "Percentage of monthly trips by the user groups (Jan to April)",
             x = NULL,
             y = "Percentage") +
        theme_minimal() +
        theme(
          legend.position = c(0.9, 0.95),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank(),
          plot.margin = unit(c(5, 5, 7, 5), 'mm')
        ) +
        geom_text(aes(label = paste0(monthly_percentage, '%')), 
                  position = position_dodge(width = 0.85), 
                  vjust = 1.1, 
                  hjust = 0.5, 
                  size = 3.0)
      
      
      #Boxplot
      
      ggplot(month_comparison, aes(member_casual, monthly_percentage, fill = member_casual)) +
        geom_boxplot() +
        labs(title = "Percentages Of Trips Per Month By Customer Group (Jan to April)",
             x = NULL,
             y = "Monthly Percentage") +
        theme_minimal() +
        theme(
          legend.position = 'none',
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank()
        )
      
      
      
#When interpreting the findings from the station usage analysis, 
#we noticed that most of the popular start stations were also on the list 
#of most popular end stations which might suggest a high amount of round trips.
# So finding out the percentage of trips that are round trips and those that
#are one-ways.
      
      
  trip_type <-  combined_data %>% 
    mutate( #making a new column
      trip_type = case_when( #deciding the values for this new column
        start_station_name == end_station_name ~ 'Round Trip',
        start_station_name != end_station_name ~ 'One Way')
    ) %>%
    group_by(member_casual, trip_type) %>% #using the new column in the group function
    summarise(trips = n()) %>%
    arrange(member_casual, desc(trips)) %>%
    group_by(member_casual) %>%
    mutate(percentage =  round(trips/sum(trips) * 100, 1)) %>% 
    ungroup()
      
    #Cross-validating the results
    
  
    #for round trips
  combined_data %>% 
    filter(start_station_name == end_station_name) %>% 
    group_by(member_casual) %>% 
    summarise(trips = n())
  
    #for one-way trips
   combined_data %>% 
     filter(start_station_name != end_station_name) %>% 
     group_by(member_casual) %>% 
     summarise(trips = n())
      
    
   #The results are correct and shows that one-way trips are actually
   #more frequent.
   
   
   #Plotting the results
     
   ggplot(trip_type, aes(member_casual, percentage, fill = trip_type)) +
     geom_bar(stat = 'identity', position = 'dodge') +
     geom_text(aes(label = paste0(percentage, '%')), 
               position = position_dodge(width = 0.85), 
               vjust = 0.9, 
               hjust = 0.5, 
               size = 3.1) +
     theme_minimal() +
     labs(title = 'Most trips are actually one-ways',
        subtitle = 'Percentage of one-way/round trips for each user group',
          x = 'User group', y = 'Percentage') +
     theme(
       legend.position = c(0.9, 0.9),
       legend.title = element_blank(),
       legend.background = element_blank(),
       legend.key = element_blank(),
       plot.margin = unit(c(6, 5, 6, 5), "mm")
     )
    
      
      
    #Displaying the distribution of trips by weekday (an earlier chart) in percentages.
    
   weekly_percentages <- weekly_rides %>% #taking the first aggregation I made
     group_by(member_casual) %>% #then grouping by user type as we want the
     #results for each user group to be distinct.
     mutate(percentage = round(num_of_rides/ sum(num_of_rides) * 100, 1)) %>% 
     ungroup() #creating a percentage column that calculates each hour's contribution to the
   #total of all hours (a day), rounds it, and then the ungroup part removes
   #the grouping. 
      
    #Plotting the results
    
   ggplot(weekly_percentages, aes(start_day_of_week, percentage, 
                                  fill = member_casual)) +
     geom_bar(stat = 'identity', position = 'dodge', width = 0.85) +
     geom_text(aes(label = paste0(percentage,'%')), 
               position = position_dodge(width = 0.85), 
               vjust = 1.5, 
               hjust = 0.5,  
               color = "black", 
               size = 2.7) +
     theme_minimal() + ylim(0, 25) +
     labs(title = 'The groups have different preferences',
       subtitle = 'Weekly distribution of trips for each user group',
          x = 'Day of Week', y = 'Percentage') +
     theme(
       legend.position = c(0.9, 0.95),
       legend.title = element_blank(),
       legend.background = element_blank(),
       legend.key = element_blank(),
       legend.text = element_text(size = 8.65),
       plot.margin = unit(c(6, 6, 6, 6), "mm")
     )
   
      
     
     # Plotting another version of the plot with the days used to facet it
     ggplot(weekly_percentages, 
            aes(percentage, member_casual, fill = member_casual)) +
       geom_bar(stat = "identity", position = 'dodge', width = 0.8) + 
       geom_text(aes(label = paste0(percentage, "%")), hjust = -0.1, size = 3) +
       facet_wrap(~start_day_of_week, scales = "free_y", ncol = 1) +
       theme_minimal() + xlim(0, 25) +
       theme(axis.text.y = element_text(size = 8.7),
             legend.position = "none",
             plot.title = element_text(size = 12, face = 'bold'),
             strip.text = element_text(size = 10),
             plot.title.position = 'panel') + 
       labs(title = 'The groups have different preferences',
         subtitle = 'Weekly distribution of trips for each user group',
            y = 'User group', x = "Percentage of weekly rides",
            caption = "Percentages are each day's contribution to the week's total rides")
     
     
      
      #Plotting the distribution of trips by hour of day in percentages
      
      #creating the aggregation
      
      hourly_percentages <- hourly_stats %>% #taking the first aggregation I made
        group_by(member_casual) %>% #then grouping by user type as we want the
        #results for each user group to be distinct.
        mutate(percentage = round(num_of_rides/sum(num_of_rides) * 100, 1)) %>% 
        ungroup()  
        #created a percentage column that calculates each hour's contribution to the
        #total of all hours (a day), rounds it, and then the ungroup part removes
        #the grouping. 
      
      
      #then the plot
      
      
      ggplot(hourly_percentages, aes(start_hour, percentage, 
                                     fill = member_casual)) +
        geom_histogram(stat = 'identity', position = 'dodge') +
       
        theme_minimal() + ylim(0, 15) +
        labs(title = 'The groups show different patterns in their hourly usage',
          subtitle = 'Percentage of trips by hour of day for each user group',
             x = 'Hour of Day', y = 'Percentage of daily rides',
             caption="Note the distinct usage patterns for commuting and leisure.") +
        theme(
          legend.position = c(0.9, 0.95),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key = element_blank(),
          legend.text = element_text(size = 8.65),
          plot.margin = unit(c(6, 6, 6, 6), "mm")
        ) + #adding boxes and labels to highlight certain time periods
        annotate("rect", xmin=6, xmax=9, ymin=0, ymax=12, alpha=0.2, fill="cyan4") +
        annotate("rect", xmin=15, xmax=18, ymin=0, ymax=12, alpha=0.2, fill="cyan4") +
        annotate("rect", xmin=12, xmax=15, ymin=0, ymax=12, alpha=0.2, fill="coral") +
        annotate("rect", xmin=18, xmax=22, ymin=0, ymax=12, alpha=0.2, fill="coral") +
        annotate("text", x=7.5, y=12, label="Morning Commute", color="cyan4", size=4, hjust=0.5) +
        annotate("text", x=16.5, y=12, label="Evening Commute", color="cyan4", size=4, hjust=0.5) +
        annotate("text", x=13.5, y=12.8, label="Afternoon Leisure", color="coral", size=4, hjust=0.5) +
        annotate("text", x=20.5, y=12.8, label="High Evening Activity", color="coral", size=4, hjust=0.5)
      
      
      
      #Plotting the station usage charts with percentages
      
      #Adding percentages to the aggregations

      
  members_weekday_start_stations_with_percentages <- combined_data %>%
    filter(member_casual == 'Member') %>% 
    group_by(start_day_of_week, start_station_name) %>% 
    summarise(num_of_rides = n()) %>% 
    arrange(start_day_of_week, desc(num_of_rides)) %>%
    ungroup() %>% #removing the grouping
    group_by(start_day_of_week) %>% #grouping by only weekday this time
    mutate(percentage = round(num_of_rides/sum(num_of_rides)*100,2)) %>% 
    #that calculated the contribution of each station to the total for each weekday
    slice_head(n = 2)
      
    #The percentages for start stations are small signifying that usage is
    #distributed among the stations  
    
  #Cross-validating the results
  
  #recreating the aggregation this time without slicing out the top rows. This way I
  #could add up the percentages and see if they added up to 100
  vvc <- combined_data %>%
  filter(member_casual == 'Member') %>%
  group_by(start_day_of_week, start_station_name) %>%
  summarise(num_of_rides = n()) %>%
  arrange(start_day_of_week, desc(num_of_rides)) %>%
  group_by(start_day_of_week) %>% #grouping by only weekday this time
  mutate(percentage = round(num_of_rides/sum(num_of_rides)*100,2))

  #adding up the percentages
  sum(vvc$percentage) 
  #the result was 701. So I need to divide this by 7 as there are 7 days
  sum(vvc$percentage)/7 #This comes out as 100% for each weekday
  
  #If the rides being distributed over a large number of stations led to the small 
  #percentages for the popular stations, then the number of stations would need to
  #be high. 
  n_distinct(combined_data$start_station_name) #counting unique station names
  #there are 838 stations and 42,674 trips in the dataset. When we average this the
  #result is 51 trips by station. Some stations would be used more often by others, 
  #and some would be used less often. But over a 4 month period, it's surprising to
  #not see large differences in usage percentages.
  rm(vvc) #deleting the aggregation

  
  
  #Creating a sample chart for the weekly start station usage for members
  
  ggplot(members_weekday_start_stations_with_percentages, 
         aes(fct_rev(start_day_of_week), num_of_rides, fill = start_station_name)) +
    geom_bar(stat = 'identity', position = 'dodge', width = 0.8) +
    geom_text(aes(label = start_station_name), 
              position = position_dodge(width = 0.8), 
              vjust = 0.3, 
              hjust = 1.2, 
              size = 3.1)  + #for the station names
    geom_text(aes(label = paste(percentage, '%', sep = '')),
              position = position_dodge(width = 0.8), 
              vjust = 0.3, 
              hjust = 0.25, 
              size = 2.8)  + #for the percentages
    theme_minimal()+
    labs(title = "Top 2 Popular Start Stations by Weekday (Members)",
         x = NULL,
         y = "Number of Trips",
         fill = 'Station Name') +
    theme(legend.position = 'none') +
    coord_flip()
  
  #The text run out of the bars giving the plot a cluttered look. So we have to use
  #a different plot as adjusting it doesn't work. 
  #Talking with ChatGPT, a solution was to facet the plot by weekday and then
  #displaying the station names in the y axis
  
  # Plotting
  ggplot(members_weekday_start_stations_with_percentages, 
         aes(percentage, reorder(start_station_name, num_of_rides), 
             #so station with most rides come first
             fill = start_station_name)) +
    geom_bar(stat = "identity") + 
    geom_text(aes(label = paste0(percentage, "%")), hjust = -0.1, size = 3) +
    facet_wrap(~start_day_of_week, scales = "free_y", ncol = 1) +
    #free_y allows the data in the y axis(station names in this case) to take their
    #own values. As we didn't specify this for the x axis, it would take the default
    #option which is fixing a specific value (percentage) to the x axis.
    theme_minimal() + xlim(0, 10) +
    theme(axis.text.y = element_text(size = 8.7),
          legend.position = "none",
          plot.title = element_text(size = 12, face = 'bold'),
          strip.text = element_text(size = 10),
          plot.title.position = 'plot') + 
    labs(title = "Each day's top 2 stations capture small percentages of total rides",
      subtitle = "Top 2 start stations by weekday (Annual Members)",
         x = "Percentage of day's total rides",
         y = "Start station")
  
  
 

  #This works so the next step is to add percentages to the remaining aggregations 
  #for station usage and then making the plots

 
  #Casual riders start staion usage with percentages
 
    casual_weekday_stations <- combined_data %>% 
      filter(member_casual == 'Casual') %>% 
      group_by(start_day_of_week, start_station_name) %>% 
      summarise(num_of_rides = n()) %>% 
      arrange(start_day_of_week, desc(num_of_rides)) %>% 
      ungroup() %>% 
      group_by(start_day_of_week) %>% 
      mutate(percentage = round(num_of_rides/sum(num_of_rides)*100, 2)) %>% 
      slice_head(n = 2)
  
  #Member end stations with percentages
  
  member_weekday_end_stations <- combined_data %>% 
    filter(member_casual == 'Member') %>% 
    group_by(end_day_of_week, end_station_name) %>% 
    summarise(num_of_rides = n()) %>% 
    arrange(end_day_of_week, desc(num_of_rides)) %>% 
    ungroup() %>% 
    group_by(end_day_of_week) %>% 
    mutate(percentage = round(num_of_rides/sum(num_of_rides)*100, 2)) %>% 
    slice_head(n = 2)
  
  #Casual end stations
  
  casual_weekday_end_stations <- combined_data %>% 
    filter(member_casual == 'Casual') %>% 
    group_by(end_day_of_week, end_station_name) %>% 
    summarise(num_of_rides = n()) %>% 
    arrange(end_day_of_week, desc(num_of_rides)) %>% 
    ungroup() %>% #ungroup is redundant here
    group_by(end_day_of_week) %>% 
    mutate(percentage = round(num_of_rides/sum(num_of_rides)*100, 2)) %>% 
    slice_head(n = 2)
  
  
  
  #Plotting the results
  
  #Casual weekday start stations 

  ggplot(casual_weekday_stations, 
         aes(percentage, start_station_name, 
             fill = start_station_name)) +
    geom_bar(stat = "identity") + xlim(0, 10) +
    geom_text(aes(label = paste0(percentage, "%")), hjust = -0.1, size = 3) +
    facet_wrap(~start_day_of_week, scales = "free_y", ncol = 1) +
    theme_minimal() + 
    theme(axis.text.y = element_text(size = 8.7),
          legend.position = "none",
          plot.title = element_text(size = 12, face = 'bold'),
          strip.text = element_text(size = 10),
          plot.title.position = 'plot') +
    labs(title = "The top 2 stations capture small percentages of the day's total rides",
         subtitle = "Top 2 start stations by weekday (Casual Riders)",
         x = "Percentage of day's total rides",
         y = "Start station")
  
  
  
  #Plotting members' end stations
  
  ggplot(member_weekday_end_stations, 
         aes(percentage, reorder(end_station_name, num_of_rides), #reorder stations
             fill = end_station_name)) +
    geom_bar(stat = 'identity') +
    geom_text(aes(label = paste0(percentage, '%')), hjust = -0.1, size = 3) +
    facet_wrap(~end_day_of_week, scales = 'free_y', ncol = 1) +
    theme_minimal() + xlim(0, 10) +
    theme(axis.text.y = element_text(size = 8.7),
          legend.position = "none",
          plot.title = element_text(size = 12, face = 'bold'),
          strip.text = element_text(size = 10),
          plot.title.position = 'plot') +
    labs(title = 'Small percentages for the end stations too',
      subtitle = "Top 2 end stations by weekday (Annual Members)",
         x = "Percentage of day's total rides",
         y = "End station")
  
  
  #And then casual end stations:
  
  ggplot(casual_weekday_end_stations, 
         aes(percentage, reorder(end_station_name, num_of_rides), 
             fill = end_station_name)) +
    geom_bar(stat = 'identity') + xlim(0, 10) +
    geom_text(aes(label = paste0(percentage, '%')), hjust = -0.1, size = 3) +
    facet_wrap(~end_day_of_week, scales = 'free_y', ncol = 1) +
    theme_minimal() + 
    theme(axis.text.y = element_text(size = 8.7),
          legend.position = "none",
          plot.title = element_text(size = 12, face = 'bold'),
          strip.text = element_text(size = 10), #text setting for the facet headers
          plot.title.position = 'plot') + #position of title
    labs(title = "Same as for the end stations",
      subtitle = "Top 2 most used end stations by weekday (Casual Riders)",
         x = "Percentage of day's total rides",
         y = "End station")
  
  
  
  
  
  
      
  #Adding percentages to the the overall popular station usage analysis
   
  #Adding percentages to the aggregations 
       
  #Popular start stations for members
  members_pop_stations <- combined_data %>% 
    filter(member_casual == 'Member') %>% 
    group_by(start_station_name) %>% 
    summarise(num_of_rides = n()) %>% 
    arrange(desc(num_of_rides)) %>% #ordering the data in desc order
    ungroup() %>% #turn off the grouping function so analysis can be performed
    #on overall dataset
    mutate(percentage = round(num_of_rides/sum(num_of_rides)*100, 2)) %>%
    #creating the percentages column
    head(10) #Selecting only the top ten stations 
      
     
  #POpular end stations for members
  members_pop_end_stations <- combined_data %>% 
    filter(member_casual == 'Member') %>% 
    group_by(end_station_name) %>% 
    summarise(num_of_rides = n()) %>% 
    arrange(desc(num_of_rides)) %>% 
    ungroup() %>% 
    mutate(percentage = round(num_of_rides/sum(num_of_rides)*100, 2)) %>% 
    head(10)
    
  
  #Doing the same for casual riders
  
  #Popular start stations for casual riders
  casual_pop_stations <- combined_data %>% 
    filter(member_casual == 'Casual') %>% 
    group_by(start_station_name) %>% 
    summarise(num_of_rides = n()) %>% 
    arrange(desc(num_of_rides)) %>% 
    ungroup() %>% 
    mutate(percentage = round(num_of_rides/sum(num_of_rides)*100, 2)) %>% 
    head(10)
      
    #End stations for casual riders
    casual_pop_end_stations <- combined_data %>% 
      filter(member_casual == 'Casual') %>% 
      group_by(end_station_name) %>% 
      summarise(num_of_rides = n()) %>% 
      arrange(desc(num_of_rides)) %>% 
      ungroup() %>% 
      mutate(percentage = round(num_of_rides/sum(num_of_rides)*100, 2)) %>% 
      head(10)
      
      
    #Plotting the results and using geom_text to display the percentages  
      
    #Members popular start stations
    
    ggplot(members_pop_stations, aes(reorder(start_station_name, num_of_rides), 
                                     num_of_rides)) +
      geom_bar(stat = 'identity', fill = '#00bfc4', width = 0.75) +
      coord_flip() +
      theme_minimal() +
      labs(title = "Top 10 start stations for annual members (Jan to April)",
           x = NULL,
           y = "Number of trips",
           caption = "Percentages are each station's contribution to the group's total trips") +
      theme(plot.title.position = "plot",
            plot.margin = unit(c(6, 5, 6, 5), "mm")) + ylim(0, 500) + #increasing axis limit
      geom_text(aes(label = paste0(percentage, '%')), hjust = -0.1, size = 3.2)
      #adding the percentages
      
    
      #Members popular end stations
    
    ggplot(members_pop_end_stations, aes(reorder(end_station_name, num_of_rides), 
                                         num_of_rides)) +
      geom_bar(stat = 'identity', fill = '#00bfc4', width = 0.75) +
      coord_flip() +
      theme_minimal() +
      labs(title = 'Most of the popular start stations are popular end stations too',
          subtitle = "Top 10 end stations for annual members (Jan to April)",
           x = NULL,
           y = "Number of trips",
           caption = "Percentages are each station's contribution to the group's total trips") +
      theme(plot.title.position = "plot",
            plot.margin = unit(c(6, 5, 6, 5), "mm")) + ylim(0, 500) +
      geom_text(aes(label = paste0(percentage, '%')), hjust = -0.1, size = 3.2)
    
      
      
      #Casual riders popular start stations
      
    ggplot(casual_pop_stations, aes(reorder(start_station_name, num_of_rides),
                                    num_of_rides)) +
      geom_bar(stat = 'identity', fill = '#f8766d', width = 0.75) +
      coord_flip() +
      theme_minimal() +
      labs(title = "Top ten start stations for casual riders (Jan to April)",
           x = NULL,
           y = "Number of trips",
           caption = "Percentages are each station's contribution to the group's total trips") +
      theme(plot.title.position = "plot",
            plot.margin = unit(c(6, 5, 6, 5), "mm")) + ylim(0, 200) +
      geom_text(aes(label = paste0(percentage, '%')), hjust = -0.1, size = 3.2)
    
    
      #Casual popular end stations
      
    ggplot(casual_pop_end_stations, aes(reorder(end_station_name, num_of_rides),
                                        num_of_rides)) +
      geom_bar(stat = 'identity', fill = '#f8766d', width = 0.75) +
      coord_flip() +
      theme_minimal() +
      labs(title = "Top 10 end stations for casual riders (Jan to April)",
           x = NULL,
           y = "Number of trips",
           caption = "Percentages are each station's contribution to the group's total trips") +
      theme(plot.title.position = "plot",
            plot.margin = unit(c(6, 5, 6, 5), "mm")) + ylim(0, 200) +
      geom_text(aes(label = paste0(percentage, '%')), hjust = -0.1, size = 3.2)
      
      
                  #Analysis for short and long duration trips  
    
      #looking at short trips (below 5 minutes), and long trips (below 15)
      #to see if their patterns are consistent with the general population
      
    #filtering out short trips
    short_trips <- combined_data %>% 
        filter(ride_duration %/% 60 <= 5) %>% #filter for trips below 5 minutes 
        mutate(ride_duration = ride_duration %/% 60) #duration to minutes
      
    #for long trips
     long_trips <- combined_data %>% 
       filter(ride_duration %/% 60 >= 15) %>% #filter for trips above 15 minutes
       mutate(ride_duration = ride_duration %/% 60)
      
     #Calculating the frequency of short trips for the user groups
      short_trip_freq <- short_trips %>%
        group_by(member_casual) %>%
        summarise(count = n()) %>%
        mutate(percentage = count / sum(count) * 100)
      print(short_trip_freq)
      
    #frequency of long trips
     long_trip_freq <- long_trips %>% 
       group_by(member_casual) %>% 
       summarise(count = n()) %>% 
       mutate(percentage = count/sum(count) * 100)
     print(long_trip_freq)
      
      
        #creating a breakdown table so we can see the proportion of trips that are
        #short and long for the user groups
     trip_breakdown <- combined_data %>% 
       group_by(member_casual) %>% 
       summarise(
         count = n(),  # Total number of rides
         long = sum(ride_duration %/% 60 >= 15),  # Number of long rides (15 minutes or more)
         short = sum(ride_duration %/% 60 <= 5)   # Number of short rides (5 minutes or less)
         ) %>% 
       mutate(
         long_per = round(long / count * 100, 1),  # Percentage of long rides
         short_per = round(short / count * 100, 1),  # Percentage of short rides
         regular_per = round(100 - (long_per + short_per), 1)  # Percentage of regular rides
       ) %>% 
       ungroup()
     
     
     
     #creating a bar plot for the calculation
     
     
     #First we need the type of rides to be in one column, and the percentages in
     #another column as we would need to plot two variables. The current data has
     #separate columns for long rides, short rides, and regular rides with their
     #percentages displayed under their respective columns. This won't work in 
     #ggplot so we have to put the ride types in one single column, and their values
     #in rows next to them and also in one single column too.
  
     
     trip_breakdown_long <- trip_breakdown %>% 
       select(member_casual, long_per, short_per, regular_per) %>%
       #selecting only the columns we need
       pivot_longer(cols = c(long_per, short_per, regular_per),
                    #combined the three colunms into one column using the c()
                    names_to = 'trip_type', #naming the new combined column
                    values_to = 'percentage') #as another column is also created
                    #to hold the values under the rows we combined, we have to name 
                    #the column and we've named it percentage
     
     #Now creating the bar chart
     
     
     ggplot(trip_breakdown_long, aes(x = member_casual, y = percentage, fill = trip_type)) +
       geom_bar(stat = "identity", position = "dodge", width = 0.8) +
       labs(title = "Proportion of Trip Durations By User Type", 
            x = "User Type", 
            y = "Percentage of Trips",
            fill = "Trip Type") +
       scale_fill_manual(values = c("#66c2a5", "#fc8d62", "#8da0cb"), #picking colors
                         labels = c("Long Trips (15+ min)", "Short Trips (<= 5 min)", "Regular Trips")) +
       #specifying the labels for the colors
       theme_minimal(base_size = 12.5) + #base_size here affects the font size
       theme(
         plot.title = element_text(hjust = 0.5), #hjust value centers the plot title
         legend.position = "top", #puts legend at top of chart
         legend.title = element_blank()
       ) +
       geom_text(aes(label = paste0(percentage, "%")), 
                 position = position_dodge(width = 0.8), 
                 color = "black", 
                 size = 3,
                 vjust = 1.1)
     
     #In the plot, the long trip bar comes first, then the short trips, befor the
     #regular trips bar. This might be confusing so it's better for the bar to be
     #arranged starting with short trips, then regular, before long trips.
     #I could probably do this by making the trip type column a factor and then
     #arranging it manually. As a failsafe, I can recreate the aggregation with the
     #original code if this doesn't work.
     
     trip_breakdown_long$trip_type <- factor(trip_breakdown_long$trip_type, 
                                             levels = c('short_per', 'regular_per', 
                                                        'long_per'), ordered = TRUE)
     #This doesn't work. The ordering is still as it is. 
     #When I observe the aggregated table, I notice that the trip types are ordered 
     #based on the order they were written in when we pivoted the aggregation. 
     #So I'll copy the pivot_longer code we used before, and order the
     #trip type how I want. 
     
    
     trip_breakdown_long <- trip_breakdown %>% 
       select(member_casual, long_per, short_per, regular_per) %>%
       #selecting only the columns we need
       pivot_longer(cols = c( short_per, regular_per, long_per),
                    #writing them in the order I want
                    names_to = 'trip_type', #naming the new combined column
                    values_to = 'percentage') 
     
     #This changed the order of the trip types. But when I run
     #the plot code again, it remains unchanged. Maybe it has to do with the order of
     #the colours I specified. I'll change that and see what happens. First I'll
     #copy the plot code, and if it works, I'll replace the original plot code with
     #the new one. So if you're confused as to what I've been trying to do all this
     #while, that's not your fault.
     
     
     ggplot(trip_breakdown_long, aes(x = member_casual, y = percentage, 
                                     fill = fct_rev(trip_type))) +
       geom_bar(stat = "identity", position = "dodge", width = 0.8) +
       labs(title = "Trip duration breakdown by user group", 
            x = "User Type", 
            y = "Percentage of Trips",
            fill = "Trip Type") +
       scale_fill_manual(values = c( "#fc8d62", "#8da0cb", "#66c2a5"), #picking colors
                         labels = c( "Short Trips (<= 5 min)", "Regular Trips", "Long Trips (15+ min)")) +
       #specifying the labels for the colors
       theme_minimal(base_size = 12.5) + #base_size here affects the font size
       theme(
         plot.title = element_text(hjust = 0.5), #hjust value centers the plot title
         legend.position = "top", #puts legend at top of chart
         legend.title = element_blank(),
         plot.margin = unit(c(6, 5, 6, 5), "mm")
       ) +
       geom_text(aes(label = paste0(percentage, "%")), 
                 position = position_dodge(width = 0.8), 
                 color = "black", 
                 size = 3,
                 vjust = 1.1)
     
     
     #It worked. So on second thoughts, I'll leave the revised plot code here. Maybe
     #I didn't need to order the factors or any of the other things I tried
     #before ordering the colours. Yeah, maybe. Also notice that I wrapped the fill
     #option with a factor reverse. This was because when plotting the trip types,
     #ggplot put the bars of long trips first instead of short trips. To understand,
     #compare the proportions in the aggregation with those in the plot.
     
     
     #Focusing on doing the analysis for short duration trips first
     
     #Calculating the distribution of short trips for the user groups
     
     short_trip_summary <- short_trips %>% 
       group_by(member_casual) %>% 
       reframe(count = n(),
               avg_duration = round(mean(ride_duration), 2),
               median_duration = median(ride_duration),
               st_dev = round(sd(ride_duration), 2)) %>% 
       mutate(trip_percentage = round(count/sum(count) * 100, 1))
     
     
     #Doing a station usage analysis to see the popular stations for short trips
    
     #top start stations (short trips) for annual members
      
      members_short_start_stations <- short_trips %>%
        filter(member_casual == 'Member') %>% 
        group_by(start_station_name) %>%
        summarise(count = n()) %>%
        mutate(percentage = round(count/sum(count) * 100, 1)) %>% 
        arrange(desc(count)) %>%
        slice_head(n = 10)
      
      #for casual riders
      
      casual_short_start_stations <- short_trips %>% 
        filter(member_casual == 'Casual') %>% 
        group_by(start_station_name) %>%
        summarise(count = n()) %>% 
        mutate(percentage = round(count/sum(count) * 100, 1)) %>% 
        arrange(desc(count)) %>% 
        slice_head(n = 10)
      
      #popular end stations 
      
      #top end stations (short trips) for annual members
      
      members_short_end_stations <- short_trips %>%
        filter(member_casual == 'Member') %>% 
        group_by(end_station_name) %>%
        summarise(count = n()) %>%
        mutate(percentage = round(count/sum(count) * 100, 1)) %>% 
        arrange(desc(count)) %>%
        slice_head(n = 10)
      
      #for casual riders
      casual_short_end_stations <- short_trips %>% 
        filter(member_casual == 'Casual') %>% 
        group_by(end_station_name) %>%
        summarise(count = n()) %>% 
        mutate(percentage = round(count/sum(count) * 100, 1)) %>% 
        arrange(desc(count)) %>% 
        slice_head(n = 10)
      
      
      
      #And then some time based analysis
      
      #First finding the distribution of usage by weekday (short trips).Each day's 
      #contribution to the total rides taken by each member group
      
      short_trips_weekly_usage <-   short_trips %>% 
        group_by(start_day_of_week, member_casual) %>% 
        summarise(num_of_trips = n(),
                  avg_duration = round(mean(ride_duration), 1),
                  median_duration = round(median(ride_duration), 1)) %>% 
        group_by(member_casual) %>% 
        mutate(day_percentage = round(num_of_trips/sum(num_of_trips) * 100, 1))
      
      #Plotting the results to observe the distribution
      
      ggplot(short_trips_weekly_usage, aes(start_day_of_week, day_percentage, 
                                           fill = member_casual)) +
        geom_bar(stat = 'identity', width = 0.8, position = 'dodge') +
        theme(legend.position = c(0.9, 0.9),
              legend.background = element_blank(),
              legend.title = element_blank(),
              legend.key = element_blank())
      
      
      
    #And now for the hourly usage (short trips too)


     short_trips_hourly_usage <-  short_trips %>% 
        group_by(start_hour, member_casual) %>% 
        summarise(num_of_rides = n(),
                  avg_duration = round(mean(ride_duration), 1),
                  median_duration = round(median(ride_duration), 1)) %>% 
        group_by(member_casual) %>% #second grouping
        mutate(hour_percentage = round(num_of_rides/sum(num_of_rides) * 100, 1))
        #calculates each hour's contribution to the daily total for each group
      
      #plotting the result using an histogram
      
     ggplot(short_trips_hourly_usage, aes(start_hour, hour_percentage, 
                                          fill = member_casual)) +
       geom_histogram(stat = 'identity', position = 'dodge') + ylim(0, 12) +
       theme(legend.position = c(0.9, 0.9),
             legend.background = element_blank(),
             legend.title = element_blank(),
             legend.key = element_blank())
      
      
      
     
     #Findings are roughly similar with the overall findings.
     
     #Now moving unto analyzing long duration trips
     
     #First a summary
     
     long_trips_summary <- long_trips %>% 
       group_by(member_casual) %>% 
       reframe(count = n(),
               avg_duration = mean(ride_duration),
               median_duration = median(ride_duration),
               st_dev = sd(ride_duration)) %>% 
       mutate(percentage = count/sum(count) * 100)
     
     
     #And then analyzing station usage
     
     #Popular start stations for members
     
     members_long_start_stations <- long_trips %>%
       filter(member_casual == 'Member') %>% 
       group_by(start_station_name) %>% 
       reframe(count = n()) %>% 
       mutate(percentage = count/sum(count) * 100) %>% 
       arrange(desc(count)) %>% 
       slice_head(n = 10)
     
     #For casuals
     
     casual_long_start_stations <- long_trips %>% 
       filter(member_casual == 'Casual') %>% 
       group_by(start_station_name) %>% 
       reframe(count = n()) %>% 
       mutate(percentage = count/sum(count) * 100) %>% 
       arrange(desc(count)) %>% 
       slice_head(n = 10)
     
       #The top 10 stations for casual riders capture 19% of total rides
       
     #Now for end stations
     
     members_long_end_stations <- long_trips %>% 
       filter(member_casual == 'Member') %>% 
       group_by(end_station_name) %>% 
       reframe(count = n()) %>% 
       mutate(percentage = count/sum(count) * 100) %>% 
       arrange(desc(count)) %>% 
       slice_head(n = 10)
       
       
    casual_long_end_stations <- long_trips %>% 
      filter(member_casual == 'Casual') %>% 
      group_by(end_station_name) %>% 
      reframe(count = n()) %>% 
      mutate(percentage =  count/sum(count) * 100) %>% 
      arrange(desc(count)) %>% 
      slice_head(n = 10)

    
    
    #Casual riders popular start stations
    
    ggplot(casual_long_start_stations, aes(reorder(start_station_name, count),
                                    percentage)) +
      geom_bar(stat = 'identity', fill = '#f8766d', width = 0.75) +
      coord_flip() +
      theme_minimal() +
      labs(title = "Top ten start stations for long trips (casual riders)",
           x = NULL,
           y = "Percentage",
           caption = "Percentages are each station's contribution to the group's total trips") +
      theme(plot.title.position = "plot",
            plot.margin = unit(c(6, 5, 6, 5), "mm")) + ylim(0, 200) +
      geom_text(aes(label = paste0(percentage, '%')), hjust = -0.1, size = 3.2)
    
    
    
           
       
       
     #And then the time based analysis
     
    #Weekday usage
    
    long_trips_weekly_usage <- long_trips %>% 
      group_by(start_day_of_week, member_casual) %>% 
      reframe(count = n(),
              avg_duration = mean(ride_duration),
              median_duration = median(ride_duration)) %>%
      group_by(member_casual) %>% 
      mutate(percentage = round(count/sum(count) * 100, 1))
      
     #plotting the results 
    ggplot(long_trips_weekly_usage, aes(start_day_of_week, percentage, 
                                         fill = member_casual)) +
      geom_bar(stat = 'identity', width = 0.8, position = 'dodge') +
      theme(legend.position = c(0.9, 0.9),
            legend.background = element_blank(),
            legend.title = element_blank(),
            legend.key = element_blank())
    
    
    
    
    # Plotting another version of the plot with the days used to facet it
    ggplot(long_trips_weekly_usage, 
           aes(percentage, member_casual, fill = member_casual)) +
      geom_bar(stat = "identity", position = 'dodge', width = 0.8) + 
      geom_text(aes(label = paste0(percentage, "%")), hjust = -0.1, size = 3) +
      facet_wrap(~start_day_of_week, scales = "free_y", ncol = 1) +
      theme_minimal() + xlim(0, 25) +
      theme(axis.text.y = element_text(size = 8.7),
            legend.position = "none",
            plot.title = element_text(size = 12, face = 'bold'),
            strip.text = element_text(size = 10),
            plot.title.position = 'panel') + 
      labs(title = 'Casual riders take 44% of their long trips during the weekend ',
           subtitle = 'Percentage of long trips by weekday for each user group',
           y = 'User group', x = 'Percentage of weekly long trips',
           caption = "Percentages are each day's contribution to the week's total rides")

     
     
     
    #for hourly usage
    
    long_trips_hourly_usage <- long_trips %>% 
      group_by(start_hour, member_casual) %>% 
      reframe(count = n(),
              avg_duration = mean(ride_duration),
              median_duration = median(ride_duration)) %>% 
      group_by(member_casual) %>% 
      mutate(percentage = round(count/sum(count) * 100, 1))
     
     
     #A plot for the results
     
    ggplot(long_trips_hourly_usage, aes(start_hour, percentage, 
                                        fill = member_casual)) +
      geom_histogram(stat = 'identity', position = 'dodge') +
      theme(legend.position = c(0.9, 0.9))
     
     #Observing how trip durations change by hour of day
     
     ggplot(long_trips_hourly_usage, aes(start_hour, avg_duration, 
                                         colour = member_casual)) +
       geom_line(stat = 'identity') +
       theme(legend.position = c(0.5, 0.9))
     
     
     #And how they change on an overall level
     
     ggplot(hourly_stats, aes(start_hour, average_duration %/%60, 
                                         colour = member_casual)) +
       geom_line(stat = 'identity') +
       theme(legend.position = c(0.5, 0.9))
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     